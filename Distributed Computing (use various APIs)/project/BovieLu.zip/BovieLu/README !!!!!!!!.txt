INSTRUCTIONS **

1. The Project solution is in the Part2Services folder. 
2. It should be called Part2Services.sln 
3. Open the solution

The Program should run right when you run it (make sure the solution is highlighted in solution explorer)
It should automatically take you to TryIt web page 
However!!, If it's giving you issues use the following steps. 


1. When you open the solution there is two projects, one is a web form TryIt and the other is the services
2. Run services to have it hosting the services and run TryIt.aspx it try the services in a web page. 

3. Make sure to run Part2Services Project first to make sure ISS Express is hosting the services 
4. Then run TryIt project to Try it (right click on App_WebReferences in TryIt Project then click on "update web/Service Refernces" If nesscesry)
5. TryIt project is not automatically set to run TryIt.aspx , So make sure TryIt.aspx is hightlighted in the solution Exporer before running